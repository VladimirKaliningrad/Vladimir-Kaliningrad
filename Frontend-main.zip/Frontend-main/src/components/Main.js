import React from "react";

const Main = () => {
  return (
    <div className="w-full px-4 lg:px-10">

    </div>
  );
};

export default Main;
