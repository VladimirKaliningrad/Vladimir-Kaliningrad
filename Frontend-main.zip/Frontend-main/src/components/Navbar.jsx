import React, { Fragment, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { logout } from "../actions/auth";
import { connect } from "react-redux";
import { CgShoppingCart } from "react-icons/cg";

const Navbar = ({ logout, isAuthenticated }) => {
  const [redirect, setRedirect] = useState(false);

  const logout_user = () => {
    logout();
    setRedirect(true);
  };

  const guestLinks = () => (
    <Fragment>
      <div className="bg-gray-300 py-1 px-2 rounded-[0.4rem]">
        <Link to="/login" className="font-semibold font-poppins">
          <span>Вход</span>
        </Link>
      </div>
      <div className="bg-[#0abab5]   py-1 px-2 rounded-[0.4rem]">
        <Link to="/signup" className="text-white font-semibold font-poppins">
          <p className="text-blue">Регистрация</p>
        </Link>
      </div>
    </Fragment>
  );

  const authLinks = () => (
    <Fragment>
      <div className="bg-[#0abab5]   py-1 px-2 rounded-[0.4rem]">
        <Link onClick={logout_user} className="text-white font-semibold">
          <p className="text-blue">Logout</p>
        </Link>
      </div>
      <Link><CgShoppingCart /></Link>
    </Fragment>
  );

  return (
    <Fragment>
      <nav>
        <div className="sticky top-0  bg-white py-[0.6rem] px-4 mx-auto lg:px-8 flex items-center justify-between z-20">
          
          <div className="sm:flex items-center relative hidden">
            <Link to="/" className="text-[#0abab5] font-semibold">
              <p className="text-3xl font-french">Item Club</p>
            </Link>
          </div>
          <div className="flex items-center gap-5 ">
            <div className="relative pr-2"></div>
            {isAuthenticated ? authLinks() : guestLinks()}
            {redirect ? <Navigate to="/" /> : <Fragment></Fragment>}
          </div>
        </div>
      </nav>
      <hr align="left" width="auto" size="1" color="#009900" />
      <nav>
        <ul className="list-style-none mr-auto flex flex-col lg:flex-row px-4 mx-auto">
          <li className="py-4 px-4 mb-4 lg:mb-0 lg:pr-2">
            <Link class="text-black hover:font-semibold font-poppins">Мужское</Link>
          </li>
          <li className="py-4 px-4 mb-4 lg:mb-0 lg:pr-2">
            <Link class="text-black hover:font-semibold font-poppins">Женское</Link>
          </li>
          <li className="py-4 px-4 mb-4 lg:mb-0 lg:pr-2">
            <Link class="text-black hover:font-semibold font-poppins">Детское</Link>
          </li>
          <li className="py-4 px-4 mb-4 lg:mb-0 lg:pr-2">
            <Link class="text-black hover:font-semibold font-poppins">LifeStyle</Link>
          </li>
        </ul>
      </nav>
    </Fragment>
  );
};

//const mapStateToProps = state => ({
//  isAuthenticated: state.auth.isAuthenticated
//});

export default connect(null, { logout })(Navbar);