// мимо вопрос, не доделано

import React from 'react';

const Activate = () => (
    <div>
        Activate
    </div>
);

export default Activate;