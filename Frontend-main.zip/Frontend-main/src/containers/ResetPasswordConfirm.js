// страничка с продолжением смены пароля, но пока что мимо вопрос

import React from 'react';

const ResetPasswordConfirm = () => (
    <div>
        ResetPasswordConfirm
    </div>
);

export default ResetPasswordConfirm;