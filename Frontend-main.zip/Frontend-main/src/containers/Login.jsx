// страничка авторизации

import React, { useState } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import { login } from "../actions/auth";

const Login = ({ login }) => {
  const [formData, setformData] = useState({
    email: "",
    password: "",
  });

  const { email, password } = formData;

  const onChange = (e) =>
    setformData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = (e) => {
    e.preventDefault();
    login(email, password);
  };

  const { ...allData } = formData;

  const canSubmit = [...Object.values(allData)].every(Boolean);

  return (
    <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-sm">
        <h1 className="mt-10 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
          Вход
        </h1>

        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
          <form onSubmit={(e) => onSubmit(e)} className="space-y-6">
            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Эл. почта
              </label>
              <div className="mt-2">
                <input
                  //className="block w-full rounded-md border-0 py-1.5 border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 placeholder-gray-300 focus:border-purple-500 focus:ring-purple-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white dark:placeholder-gray-400 dark:focus:border-purple-500 dark:focus:ring-purple-500 [&:not(:placeholder-shown):not(:focus):invalid~span]:block invalid:[&:not(:placeholder-shown):not(:focus)]:border-red-400 valid:[&:not(:placeholder-shown)]:border-green-500"
                  className="block w-full rounded-md border-0 py-1.5 px-4 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm font-semibold sm:leading-6 [&:not(:placeholder-shown):not(:focus):invalid~span]:block invalid:[&:not(:placeholder-active):not(:focus)]:border-red-400 valid:[&:not(:placeholder-shown)]:border-green-500"
                  type="email"
                  name="email"
                  autoComplete="off"
                  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
                  required
                  onChange={(e) => onChange(e)}
                />
                <span className="mt-1 text-sm hidden text-red-400">
                  Введите правильный адрес.{" "}
                </span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label
                  htmlFor="password"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Пароль
                </label>
                <div className="text-sm">
                  <Link
                    to="/reset_password"
                    className="font-semibold text-[#0abab5] hover:text-indigo-500"
                  >
                    Забыли пароль?
                  </Link>
                </div>
              </div>
              <div className="mt-2 items-start">
                <input
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6 [&:not(:placeholder-shown):not(:focus):invalid~span]:block invalid:[&:not(:placeholder-shown):not(:focus)]:border-red-400 valid:[&:not(:placeholder-shown)]:border-green-500"
                  type="password"
                  name="password"
                  autoComplete="off"
                  pattern="[0-9a-zA-Z]{8,}"
                  required
                  onChange={(e) => onChange(e)}
                />
                <span className="mt-1 hidden text-sm text-red-400">
                  Пароль должен содержать минимум 8 символов.{" "}
                </span>
              </div>
            </div>

            <button
              disabled={!canSubmit}
              className="flex w-full justify-center rounded-md bg-[#0abab5] px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              type="submit"
            >
              Вход
            </button>
          </form>
        </div>

        <p className="mt-10 text-center text-sm text-gray-500">
          Нет аккаунта?{" "}
          <Link to="signup" className="font-semibold leading-6 text-[#0abab5]">
            Зарегистрироваться
          </Link>
        </p>
      </div>
    </div>
  );
};

//const mapStateToProps = state => ({
//   isAuthenticated: state.auth.isAuthenticated
//});

export default connect(null, { login })(Login);
