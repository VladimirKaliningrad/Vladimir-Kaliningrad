// мимо вопрос, недоделано

import React from 'react';

const Home = () => (
    <div>
    </div>
);

export default Home;