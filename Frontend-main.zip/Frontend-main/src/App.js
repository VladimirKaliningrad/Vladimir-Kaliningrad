import Main from "./components/Main";
import Navbar from "./components/Navbar";

import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Provider } from 'react-redux';

import store from './store'
import Activate from './containers/Activate';
import Home from './containers/Home';
import Login from './containers/Login';
import ResetPassword from './containers/ResetPassword';
import ResetPasswordConfirm from './containers/ResetPasswordConfirm';
import Signup from './containers/Signup';


function App() {
  return (

    <Provider store={store}>
    <Router>
    <Navbar/>
        <Routes>
            <Route exact path='/' element={<Home/>} />
            <Route exact path='/login' element={<Login/>} />
            <Route exact path='/signup' element={<Signup/>} />
            <Route exact path='/reset_password' element={<ResetPassword/>} />
            <Route exact path='/password/reset/confirm/:uid/:token' element={<ResetPasswordConfirm/>} />
            <Route exact path='/activate/:uid/:token' element={<Activate/>} />
        </Routes>

</Router>
</Provider>


//    <div className="bg-[#f7f7f8]  ">
//      {/* Navbar */}
//      <Navbar />
//      <div className="flex ">
//        {/* Main */}
//        <Main />
//      </div>
//    </div>
  );
}

export default App;
