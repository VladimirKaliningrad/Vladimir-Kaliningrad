// Ебанный сыр, какой-то механизм store из библиотеки redux, там вроде react начинается не справляться с распределением и вместо ебли мозгов все проблемы сбрасываются на redux 
// и он уже автоматически распределяет все

import { configureStore  } from '@reduxjs/toolkit';
import rootReducer from './reducers';
import { combineReducers } from 'redux'

const initialState = {};


const reducer = combineReducers({
    rootReducer,
    initialState
})

const store = configureStore({
  reducer
})

export default store;
