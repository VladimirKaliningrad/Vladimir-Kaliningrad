// Тут система авторизации с запросами данных на сервер

import axios from "axios";
import {
  LOGIN_SUCCESS,
  LOGIN_FAIL,
  USER_LOADED_SUCCESS,
  USER_LOADED_FAIL,
  LOGOUT,
  SIGNUP_SUCCESS,
  SIGNUP_FAIL,
  PASSWORD_RESET_SUCCESS,
  PASSWORD_RESET_FAIL
} from "./types";

export const load_user = () => async (dispatch) => {
  // загрузка пользователя
  if (localStorage.getItem("access")) {
    const config = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `JWT ${localStorage.getItem("access")}`, // с кавычками прикол какой-то был
        Accept: "application/json",
      },
    };

    try {
      const response = await axios.get(
        "http://localhost:8000/auth/users/me/",
        config
      );
      dispatch({
        type: USER_LOADED_SUCCESS,
        payload: response.data,
      });
    } catch (err) {
      dispatch({
        type: USER_LOADED_FAIL,
      });
    }
  } else {
    dispatch({
      type: USER_LOADED_FAIL,
    });
  }
};

export const signup = (first_name, last_name, email, password, re_password) => async dispatch => {
  const config = {
      headers: {
          'Content-Type': 'application/json'
      }
  };

  const body = JSON.stringify({ first_name, last_name, email, password, re_password });

  try {
      const res = await axios.post(`${process.env.REACT_APP_API_URL}/auth/users/`, body, config);

      dispatch({
          type: SIGNUP_SUCCESS,
          payload: res.data
      });
  } catch (err) {
      dispatch({
          type: SIGNUP_FAIL
      })
  }
};

export const login = (email, password) => async (dispatch) => {
  // авторизация пользователя
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };

  const body = JSON.stringify({ email, password });

  try {
    //const response = await axios.post(`${process.env.REACT_APP_API_ULR}/auth/jwt/create/`, body, config); // тут тоже офигенные кавычки
    const response = await axios.post(
      "http://localhost:8000/auth/jwt/create/",
      body,
      config
    );
    dispatch({
      type: LOGIN_SUCCESS,
      payload: response.data,
    });

    dispatch(load_user());
  } catch (err) {
    dispatch({
      type: LOGIN_FAIL,
    });
  }
};

export const logout = () => dispatch => {
    dispatch({
        type: LOGOUT
    });
};

export const reset_password = (email) => async dispatch => {
  const config = {
      headers: {
          'Content-Type': 'application/json'
      }
  };

  const body = JSON.stringify({ email });

  try {
      await axios.post(`${process.env.REACT_APP_API_URL}/auth/users/reset_password/`, body, config);

      dispatch({
          type: PASSWORD_RESET_SUCCESS
      });
  } catch (err) {
      dispatch({
          type: PASSWORD_RESET_FAIL
      });
  }
};