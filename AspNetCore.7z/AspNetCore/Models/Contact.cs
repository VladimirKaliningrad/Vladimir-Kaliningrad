﻿using DocumentFormat.OpenXml.Wordprocessing;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace AspNetCore.Models
{
    public class Contact
    {
        
        [Display(Name = "Введите Имя")]
        [Required(ErrorMessage = "Вам нужно ввести имя")]
        public string Name { get; set; }


        [Display(Name = "Введите Фамилию")]
        [Required(ErrorMessage = " Вам нужно вести свою фамилию")]
        public  string Surname { get; set; }
        
        [Display(Name = "Возраст")]
        [Required(ErrorMessage = "Необходимо ввести возраст")]
        public int Age { get; set; }
        
        [Display(Name = "Введите свою электронную почту")]
        [Required(ErrorMessage = "Введите электронную почту")]
        public string Email { get; set; }
        
        [Display(Name = "Введите сообщение")]
        [StringLength(30, ErrorMessage ="Текст не менее 30 символов")]
        [Required(ErrorMessage = "Вам нужно ввести сообщение")]
        public string Message { get; set; }

    }
}
